# stunnel known port maintainers


* Cygwin
  - Andrew Schulman <andrex@alumni.utexas.net>
* Debian GNU/Linux
  - Peter Pentchev <roam@ringlet.net>
* FreeBSD
  - Ryan Steinmetz <zi@FreeBSD.org>
* NetBSD
  - Martti Kuparinen <martti.kuparinen@iki.fi>
* OpenBSD
  - Gleydson Soares <gsoares@openbsd.org>
* OpenCSW Solaris
  - Dagobert Michelsen <dam@opencsw.org>
* RedHat Linux
  - Damien Miller <dmiller@ilogic.com.au>
